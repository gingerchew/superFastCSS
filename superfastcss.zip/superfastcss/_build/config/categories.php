<?php
$cats = array (
  0 => 'superFastCSS',
);
return $cats;
