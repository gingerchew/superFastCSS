superFastCSS Extra for MODx Revolution
=======================================


**Author:** Frankie <> [Frankie.tech](frankie.tech)

Documentation is available at [Frankie.tech]()

superFastCSS: a super fast way to get super fast CSS
